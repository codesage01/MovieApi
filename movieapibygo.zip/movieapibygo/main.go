package main

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
	data "movieapi.com/hp/go/Data"
)

var movie []data.Movie

func MovieHandle(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(movie)

}
func deleteHandle(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	params := mux.Vars(r)
	for index, item := range movie {
		if item.Id == params["Id"] {
			movie = append(movie[:index], movie[index+1:]...)
			break
		}
		json.NewEncoder(w).Encode(item)
	}

}
func GetMovie(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	params := mux.Vars(r)
	for _, item := range movie {
		if item.Id == params["Id"] {
			json.NewEncoder(w).Encode(item)
			return
		}
	}
}
func CreateHandle(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	var movies data.Movie
	_ = json.NewDecoder(r.Body).Decode(&movies)
	movies.Id = strconv.Itoa(rand.Intn(100000000))
	movie = append(movie, movies)
	json.NewEncoder(w).Encode(&movies)

}
func updateHandle(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	parse := mux.Vars(r)
	for index, item := range movie {
		var movies data.Movie
		if item.Id == parse["Id"] {
			movie = append(movie[:index], movie[index+1:]...)

			_ = json.NewDecoder(r.Body).Decode(&movies)
			movies.Id = strconv.Itoa(rand.Intn(100000000))
			movie = append(movie, movies)

			json.NewEncoder(w).Encode(&movies)
		}
	}

}

func main() {

	movie = append(movie, data.Movie{Id: "1", Name: "TopGun"})
	server := mux.NewRouter()
	server.HandleFunc("/movie", MovieHandle).Methods("GET")
	server.HandleFunc("/movie/id", GetMovie).Methods("GET")
	server.HandleFunc("/movie/create", updateHandle).Methods("POST")
	server.HandleFunc("/movie/update", MovieHandle).Methods("PUT")
	server.HandleFunc("/moviedelete", deleteHandle).Methods("DELETE")
	// this is for error handling
	fmt.Println("server with port :7887 is starting ")
	err := http.ListenAndServe(":7887", server)
	if err != nil {
		fmt.Println("ERROR")
		//log.Fatal(err)
	}
}
