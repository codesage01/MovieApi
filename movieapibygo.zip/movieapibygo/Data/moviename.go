package data

type Movie struct {
	Name string `json:"Name"`
	Id   string `json:"Id"`
	//	Director Director `json:"Director`
}

/*type Director struct {
	Firstname string `json:"firstname"`
	Lastname  string `json:lastname`
}*/
